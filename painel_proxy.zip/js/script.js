setInterval(function () {
  alert("Olá");
}, 2000);
